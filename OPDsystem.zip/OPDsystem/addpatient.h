#ifndef ADDPATIENT_H
#define ADDPATIENT_H
#include <iostream>
#include <vector>
#include <iomanip>
#include <QMainWindow>
#include <QMessageBox>
#include <displaypatients.h>
#include <home.h>
using namespace std;

namespace Ui {
class addPatient;
}

class addPatient : public QMainWindow
{
    Q_OBJECT

public:
    explicit addPatient(QWidget *parent = nullptr);
    ~addPatient();

    bool updatePatientRoom(const QString &name, int room);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::addPatient *ui;
    bool isRoomOccupied(int room);


};



#endif // ADDPATIENT_H
