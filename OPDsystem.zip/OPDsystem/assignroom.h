#ifndef ASSIGNROOM_H
#define ASSIGNROOM_H
#include <home.h>

#include <QMainWindow>

namespace Ui {
class assignroom;
}

class assignroom : public QMainWindow
{
    Q_OBJECT

public:
    explicit assignroom(QWidget *parent = nullptr);
    ~assignroom();

private slots:
    void on_pushButton_clicked();

    void on_assign_clicked();

private:
    Ui::assignroom *ui;
};

#endif // ASSIGNROOM_H
