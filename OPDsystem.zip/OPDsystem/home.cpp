#include "home.h"
#include "ui_home.h"
#include "assignroom.h"


Home::Home(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Home),
    assignroomWindow(nullptr)


{
    ui->setupUi(this);
}

Home::~Home()
{
    delete ui;
}

void Home::on_AddPatient_clicked()
{
     this->hide();
     addPatient *addpatient = new addPatient();
     addpatient->show();


}


void Home::on_assignroom_clicked()
{
    if (!assignroomWindow) {
        assignroomWindow = new assignroom(this);  // Pass 'this' as parent if needed
    }
    assignroomWindow->show();
    this->hide();

}




