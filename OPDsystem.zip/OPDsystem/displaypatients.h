#ifndef DISPLAYPATIENTS_H
#define DISPLAYPATIENTS_H
#include <QWidget>
#include <QTableWidget>
#include <QMainWindow>
#include "patient.h"

// Forward declaration
class addPatient;

namespace Ui {
class displayPatients;
}

class displayPatients : public QMainWindow
{
    Q_OBJECT

public:
    explicit displayPatients(QWidget *parent = nullptr);
    ~displayPatients();

   void setPatient(const std::vector<Patient> &patients);

private slots:
    void on_pushButton_clicked();

private:
    Ui::displayPatients *ui;
    addPatient *addPatientWindow;
};

#endif // DISPLAYPATIENTS_H
