#include "assignroom.h"
#include "ui_assignroom.h"

assignroom::assignroom(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::assignroom)
{
    ui->setupUi(this);


}

assignroom::~assignroom()
{
    delete ui;
}

void assignroom::on_pushButton_clicked()
{
    if (parentWidget()) {
        parentWidget()->show();
    }
    this->hide();
}


void assignroom::on_assign_clicked()
{
    QString name = ui->name->text();
    int room = ui->consultingRoomLineEdit_2->text().toInt();
    addPatient *addPatientWindow = qobject_cast<addPatient*>(parentWidget());
      bool success = addPatientWindow->updatePatientRoom(name, room);
        if (success)
        {
            QMessageBox::information(this, "Success", QString("%1 has been assigned to room %2").arg(name).arg(room));
        }
        else{
             QMessageBox::warning(this, "Error", "could not assign room");
        }

}

