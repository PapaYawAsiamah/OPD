#ifndef HOME_H
#define HOME_H
#include <addpatient.h>
#include <assignroom.h>

#include <QMainWindow>

// Forward declaration
class assignroom;

namespace Ui {
class Home;
}

class Home : public QMainWindow
{
    Q_OBJECT

public:
    explicit Home(QWidget *parent = nullptr);
    ~Home();

private slots:
    void on_AddPatient_clicked();

    void on_assignroom_clicked();

    void on_diaplay_clicked();

private:
    Ui::Home *ui;
    assignroom *assignroomWindow;
};

#endif // HOME_H
