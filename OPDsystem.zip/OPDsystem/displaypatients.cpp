#include "displaypatients.h"
#include "ui_displaypatients.h"
#include "patient.h"
#include <vector>
#include "addpatient.h"



displayPatients::displayPatients(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::displayPatients),
     addPatientWindow(nullptr)
{
    ui->setupUi(this);
}

displayPatients::~displayPatients()
{
    delete ui;
}
void displayPatients::setPatient(const std::vector<Patient> &patients)
{

    ui->tableWidget->setRowCount(patients.size());
    ui->tableWidget->setColumnCount(7);

    QStringList headers;
    headers << "Name" << "Age" << "Gender" << "Room" << "Weight"<<"Height" << "Temperature";
    ui->tableWidget->setHorizontalHeaderLabels(headers);



    for (int row = 0; row < patients.size(); ++row)
    {
        const Patient &patient = patients[row];
        ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::fromStdString(patient.getName())));
        ui->tableWidget->setItem(row, 1, new QTableWidgetItem(QString::number(patient.getAge())));
        ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString::fromStdString(patient.getGender())));
        ui->tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(patient.getRoomNumber())));
        ui->tableWidget->setItem(row, 4, new QTableWidgetItem(QString::number(patient.getWeight())));
        ui->tableWidget->setItem(row, 5, new QTableWidgetItem(QString::number(patient.getHeight())));
        ui->tableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(patient.getTemperature())));
    }

}

void displayPatients::on_pushButton_clicked()
{
    if (!addPatientWindow) {
        addPatientWindow = new addPatient();
    }
    addPatientWindow->show();
    this->close();
}

