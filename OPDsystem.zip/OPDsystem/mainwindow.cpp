#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString Username = ui->line_edit_username->text();
    QString Password = ui->line_edit_password->text();

    if (Username == "groupE" && Password == "GPE"){

        QMessageBox::information(this, "OPD","Login Successful");
        this->hide();
        Home *home =  new Home();
        home->show();

    }
    else{
        QMessageBox::warning(this, "OPD", "Please check credentials");
    }

}

