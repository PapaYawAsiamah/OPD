#include "addpatient.h"
#include "ui_addpatient.h"
#include "patient.h"
#include "home.h"
#include <vector>

std::vector<Patient> patients;

addPatient::addPatient(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::addPatient)
{
    ui->setupUi(this);
}

addPatient::~addPatient()
{
    delete ui;
}
bool addPatient::isRoomOccupied(int room)
{
    for (const auto &patient : patients)
    {
        if (patient.getRoomNumber() == room)
        {
            return true;
        }
    }
    return false;
}


Patient newPatient;

void addPatient::on_pushButton_clicked()
{

    extern std::vector<Patient> patients;


    newPatient.providePatientInfo(ui->Name->text(), ui->Age->text(), ui->Gender->text(),ui->Temperature->text(),ui->Height->text(),ui->Weight->text());





    patients.push_back(newPatient);
    newPatient.printDetails();


    QMessageBox::information(this, "OPD","Patient added successfully");
}


void addPatient::on_pushButton_2_clicked()
{
    this->hide();
    displayPatients *displaypatients = new displayPatients();
    displaypatients->setPatient(patients);  // Pass the patients list to the display widget
    displaypatients->show();



    // Display the patient's information on the new page
    // displaypatients->setPatient(newPatient);
    // displaypatients->show();
    // this->hide();

}
bool addPatient::updatePatientRoom(const QString &name, int room)
{
    if (isRoomOccupied(room))
    {
        QMessageBox::warning(this, "Room Occupied", "The room number is already occupied.");


    } else {

            for (Patient &patient : patients)
            {
                if (patient.getName() == name.toStdString())
                {
                    patient.assignRoom(room);


                    return true;
                }
            }


                QMessageBox::warning(this, "Error", "patient does not exist");
                return false;



    }
  return false;

}


void addPatient::on_pushButton_3_clicked()
{
    this->hide();
    Home *home = new Home();   // Assuming Home is the main window
    home->show();
}

