#ifndef PATIENTLIST_H
#define PATIENTLIST_H

#include <vector>
#include "patient.h"

extern std::vector<Patient> patients;

#endif // PATIENTLIST_H
