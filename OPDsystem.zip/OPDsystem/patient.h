#ifndef PATIENT_H
#define PATIENT_H
#include <QString>
#include <string>
#include <iostream>
using namespace std;

class Patient {

private:
    std::string name;
    int age;
    std::string gender;
    int roomnumber;
    float weight;
    float height;
    float temperature;

public:
    Patient(const std::string &name, int age, const std::string &gender, int roomnumber, float weight,  float height,  float temperature);


    std::string getName() const { return name; }
    int getAge() const { return age; }
    std::string getGender() const { return gender; }
    int getRoomNumber() const { return roomnumber; }
    float getWeight() const{return weight; }
    float getHeight() const{return height;}
    float getTemperature() const{return temperature;}



    Patient() : roomnumber(-1) {}

    void providePatientInfo(const QString &Name, const QString &Age, const QString &Gender,const QString &Weight, const QString &Height, const QString &Temperature) {
        name = Name.toStdString();
        age = Age.toInt();
        gender = Gender.toStdString();
        weight = Weight.toFloat();
        height = Height.toFloat();
        temperature = Temperature.toFloat();
    }

    void assignRoom(int room) {
        roomnumber = room;
    }
    void printDetails() const {
        cout << "Patient Details:\n"
             << "Name: " << name << "\n"
             << "Age: " << age << "\n"
             << "Gender: " << gender << "\n"
             << "Room Number: " << roomnumber << "\n"
             << "Weight: " << weight << "\n"
             << "Height: " << height << "\n"
             << "Temperature: " << temperature << "\n";
    }

};

#endif // PATIENT_H
