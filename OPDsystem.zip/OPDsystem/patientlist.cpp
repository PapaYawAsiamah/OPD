#include "patientlist.h"

std::vector<Patient> patients;
